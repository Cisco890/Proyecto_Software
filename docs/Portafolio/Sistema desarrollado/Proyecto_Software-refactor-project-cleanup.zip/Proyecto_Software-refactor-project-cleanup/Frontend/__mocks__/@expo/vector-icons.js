export const Ionicons = () => null;
